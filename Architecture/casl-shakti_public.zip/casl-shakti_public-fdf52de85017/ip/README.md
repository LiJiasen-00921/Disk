This folder contains the various open source IP blocks (IIT-Madras originated and 3rd party) being used by various cores.
