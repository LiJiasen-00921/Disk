This repository holds the design docs and the publcic standards referenced in the designs.

