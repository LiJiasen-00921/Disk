This folder contains generic modules which can be used in multiple cores as is or with slight modifications.
