Vector Extension for SHAKTI
===========================
This is a Work In Progress of a Vector Accelerator for Shakti Cores broadly inspired by the Hwacha Vector Accelerator from UC Berkeley. It is based on Hwacha ISA.
