IBM's Floating point test vectors (Floating-Point Test Generator - FPgen) are used for logical verification of FPU modules
and are under the copyright of IBM.
For more information on FPgen:
https://www.research.ibm.com/haifa/projects/verification/fpgen/ieeets.html

