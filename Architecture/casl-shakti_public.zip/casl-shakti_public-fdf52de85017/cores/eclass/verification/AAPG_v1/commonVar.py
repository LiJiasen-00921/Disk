#Author: Nandu Raj P ( nndurj@gmail.com )	



instructionNumber=3
numberOfLoops=0
unusedRegs=[]
branchRegisters=[]


if __name__ == "__main__":
	print("Please Run aapg.py")
