This directory is orgainzed into a directory containing modules common to all cores
and a directory per core class. 
