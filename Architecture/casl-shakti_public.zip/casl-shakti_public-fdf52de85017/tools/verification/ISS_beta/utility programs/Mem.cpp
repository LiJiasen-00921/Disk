#include <stdio.h>

bool* Mem(int64_t memloc)
{
	for(int i = 0; i <64; i++) {
	    if(i%2==0)
		outofbound[i] = 1; 
	    else
		outofbound[i] = 0; 
	} 
	if((memloc < 1048576) && (memloc >= 0))
	{
		//printf("%d \n", memloc);
		//printf("%x \n", Memomemloc);
		return Memo[memloc];
	}
	else
	{
		//struct memnode * temp = (struct memnode *)malloc(sizeof(struct memnode));
		//temp = memex->head;
		//while(temp != NULL)
		//{
		//	if(temp->memloc == memloc)
		//		return temp->memval;
		//	temp = temp->next;
		//}
		//addmemq(memloc, memex);
		return outofbound; 
	}
}
